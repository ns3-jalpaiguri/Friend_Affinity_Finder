#!C:\Users\ADMIN\AppData\Local\Programs\Python\Python37\python.exe

import cgi
import csv

print('Content-type:text/html\r\n\r\n')

flag = 0
# now the main working body ....

print('<html>')
print('<body>')

# fetchhing the submitting ratings of the 5 dimensions....(a for attributes)
form = cgi.FieldStorage()
a1 = float(form.getfirst('a1')) #Agreeableness
a2 = float(form.getfirst('a2')) #Conscientiousness
a3 = float(form.getfirst('a3')) #Extraversion
a4 = float(form.getfirst('a4')) #Emotional Range
a5 = float(form.getfirst('a5')) #Openness

input_list = [a1, a2, a3, a4, a5]

# module for calculating H-B Distance [START]
def HB(v1, v2):
    return (sum((p**.5-q**.5)**2 for p, q in zip(v1, v2)) ** .5)/1.414
# module [END]

hbd = [] # list (vector) containing the H-B Distances
# reading the dummy dataset ...

data_path = 'Custom_user.csv'
with open(data_path, 'r') as f:
    reader = csv.reader(f, delimiter=',')
    # get header from first row
    headers = next(reader)
    # get all the rows as a list
    data = list(reader)

for i in range(0, len(data)):
    data[i][2:] = [float(x) for x in data[i][2:]]
    x = HB(input_list,data[i][2:])
    hbd.append(x)

index = sorted(range(len(hbd)), key = lambda i: hbd[i], reverse = True)[-5:] # indices of the rows yielding 5 least H-B Distances

# displaying....by embedding HTML with Python...
html_str_1 = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Title -->
    <title>FAFinder</title>

    <!-- Favicon -->
    <link rel="icon" href="./img/core-img/favicon.png">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

    <!-- Stylesheet -->
    <link rel="stylesheet" href="style.css">

</head>
    <!-- Preloader -->
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!-- /Preloader -->

    <!-- Header Area Start -->
    <header class="header-area">
        <!-- Search Form -->
        <div class="search-form d-flex align-items-center">
            <div class="container">
                <form action="index.html" method="get">
                    <input type="search" name="search-form-input" id="searchFormInput" placeholder="Type your keyword ...">
                    <button type="submit"><i class="icon_search"></i></button>
                </form>
            </div>
        </div>

        <!-- Top Header Area Start -->
        <div class="top-header-area">
            <div class="container">
                <div class="row">

                    <div class="col-7">
                        <div class="top-header-content">
                            <a href="#"> <span><font color=lightblue>FA</font>Finder</span></a>                          
                        </div>
                    </div>

                    <div class="col-5">
                        <div class="top-header-content">
                            <div class="top-social-area ml-auto">
                               <a href="http://localhost/friend_affinity_finder/index.html"><i class="fa fa-home"></i> <span>Home</span></a>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <!-- Top Header Area End -->
        </div>
    </section>
    
    
    <div class="hotel-search-form-area">
    
                        <div class="row text-center">
                            <div class="col-12 col-md-12 col-lg-12 ">
                            
                    
                            <h1>SCROLL DOWN TO FIND YOUR SUGGESTED FRIENDS.....</h1>
</div>
    </div>
            </div>

            <section class="roberto-rooms-area">
                <div class="rooms-slides owl-carousel">
"""

html_str_2 = """
    <div class="single-room-slide d-flex align-items-center">
    <div class="room-thumbnail h-100 bg-img" style="background-image: url(img/users/user1.jpg);"></div>
    <div class="room-content">
    <h2 data-animation="fadeInUp" data-delay="100ms">
    Name : 
""" + data[index[4]][1] + """
    </h2>
    <h3 data-animation="fadeInUp" data-delay="300ms">
    Username
    <span>/ user1:
""" + data[index[4]][0] + """
    </span></h3>
    <ul class="room-feature" data-animation="fadeInUp" data-delay="500ms">
    <li><span><i class="fa fa-check"></i> 
    Agreeableness
    </span> <span>: 
    """ + " " + str(data[index[4]][2]) + """
    </span></li>
    <li><span><i class="fa fa-check"></i>
     Conscientiousness
    </span> <span>:
    """ + " " + str(data[index[4]][3]) + """
    </span></h3>
    <li><span><i class="fa fa-check"></i> 
     Extraversion
    </span> <span>:
    """ + " " + str(data[index[4]][4]) + """
    </span></li>
    <li><span><i class="fa fa-check"></i> 
     Emotional range
    </span> <span>:
    """ + " " + str(data[index[4]][5]) + """
    </span></li>
    <li><span><i class="fa fa-check"></i> 
     Openness
     </span><span>:
    """ + " " + str(data[index[4]][6]) + """
    </span></li>
    <li><span><i class="fa fa-check"></i> 
     OVERALL hbd SCORE (in %)
     </span><span>:
    """ + " " + str(100 - hbd[index[4]]*100/3.54)+ """
    </span></li>
    </ul>
    </div></div>
    """

html_str_3 = """
    <div class="single-room-slide d-flex align-items-center">
    <div class="room-thumbnail h-100 bg-img" style="background-image: url(img/users/user22.jpg);"></div>
    <div class="room-content">
    <h2 data-animation="fadeInUp" data-delay="100ms">
    Name : 
""" + data[index[3]][1] + """
    </h2>
    <h3 data-animation="fadeInUp" data-delay="300ms">
    Username
    <span>/ user2:
""" + data[index[3]][0] + """
    </span></h3>
    <ul class="room-feature" data-animation="fadeInUp" data-delay="500ms">
    <li><span><i class="fa fa-check"></i> 
    Agreeableness
    </span> <span>: 
    """ + " " + str(data[index[3]][2]) + """
    </span></li>
    <li><span><i class="fa fa-check"></i>
     Conscientiousness
    </span> <span>:
    """ + " " + str(data[index[3]][3]) + """
    </span></h3>
    <li><span><i class="fa fa-check"></i> 
     Extraversion
    </span> <span>:
    """ + " " + str(data[index[3]][4]) + """
    </span></li>
    <li><span><i class="fa fa-check"></i> 
     Emotional range
    </span> <span>:
    """ + " " + str(data[index[3]][5]) + """
    </span></li>
    <li><span><i class="fa fa-check"></i> 
     Openness
    </span> <span>:
    """ + " " + str(data[index[3]][6]) + """
    </span></li>
    <li><span><i class="fa fa-check"></i> 
     OVERALL hbd SCORE (in %)
     </span><span>:
    """ + " " + str(100 - hbd[index[3]]*100/3.54) + """
    </span></li>
    </ul>
    </div></div>
    """

html_str_4 = """
    <div class="single-room-slide d-flex align-items-center">
    <div class="room-thumbnail h-100 bg-img" style="background-image: url(img/users/user3.jpg);"></div>
    <div class="room-content">
    <h2 data-animation="fadeInUp" data-delay="100ms">
    Name : 
""" + data[index[2]][1] + """
    </h2>
    <h3 data-animation="fadeInUp" data-delay="300ms">
    Username
    <span>/ user3:
""" + data[index[2]][0] + """
    </span></h3>
    <ul class="room-feature" data-animation="fadeInUp" data-delay="500ms">
    <li><span><i class="fa fa-check"></i> 
    Agreeableness
    </span> <span>: 
    """ + " " + str(data[index[2]][2]) + """
    </span></li>
    <li><span><i class="fa fa-check"></i>
     Conscientiousness
    </span> <span>:
    """ + " " + str(data[index[2]][3]) + """
    </span></h3>
    <li><span><i class="fa fa-check"></i> 
     Extraversion
    </span> <span>:
    """ + " " + str(data[index[2]][4]) + """
    </span></li>
    <li><span><i class="fa fa-check"></i> 
     Emotional range
    </span> <span>:
    """ + " " + str(data[index[2]][5]) + """
    </span></li>
    <li><span><i class="fa fa-check"></i> 
     Openness
    </span> <span>:
    """ + " " + str(data[index[2]][6]) + """
    </span></li>
    <li><span><i class="fa fa-check"></i> 
     OVERALL hbd SCORE (in %)
     </span><span>:
    """ + " " + str(100 - hbd[index[2]]*100/3.54) + """
    </span></li>
    </ul>
    </div></div>
    """

html_str_5 = """
    <div class="single-room-slide d-flex align-items-center">
    <div class="room-thumbnail h-100 bg-img" style="background-image: url(img/users/user44.jpg);"></div>
    <div class="room-content">
    <h2 data-animation="fadeInUp" data-delay="100ms">
    Name : 
""" + data[index[1]][1] + """
    </h2>
    <h3 data-animation="fadeInUp" data-delay="300ms">
    Username
    <span>/ user4:
""" + data[index[1]][0] + """
    </span></h3>
    <ul class="room-feature" data-animation="fadeInUp" data-delay="500ms">
    <li><span><i class="fa fa-check"></i> 
    Agreeableness
    </span> <span>: 
    """ + " " + str(data[index[1]][2]) + """
    </span></li>
    <li><span><i class="fa fa-check"></i>
     Conscientiousness
    </span> <span>:
    """ + " " + str(data[index[1]][3]) + """
    </span></h3>
    <li><span><i class="fa fa-check"></i> 
     Extraversion
    </span> <span>:
    """ + " " + str(data[index[1]][4]) + """
    </span></li>
    <li><span><i class="fa fa-check"></i> 
     Emotional range
    </span> <span>:
    """ + " " + str(data[index[1]][5]) + """
    </span></li>
    <li><span><i class="fa fa-check"></i> 
     Openness
    </span> <span>:
    """ + " " + str(data[index[1]][6]) + """
    </span></li>
    <li><span><i class="fa fa-check"></i> 
     OVERALL hbd SCORE (in %)
     </span><span>:
    """ + " " + str(100 - hbd[index[1]]*100/3.54) + """
    </span></li>
    </ul>
    </div></div>
    """

html_str_6 = """
    <div class="single-room-slide d-flex align-items-center">
    <div class="room-thumbnail h-100 bg-img" style="background-image: url(img/users/user5.jpg);"></div>
    <div class="room-content">
    <h2 data-animation="fadeInUp" data-delay="100ms">
    Name : 
""" + data[index[0]][1] + """
    </h2>
    <h3 data-animation="fadeInUp" data-delay="300ms">
    Username
    <span>/ user5:
""" + data[index[0]][0] + """
    </span></h3>
    <ul class="room-feature" data-animation="fadeInUp" data-delay="500ms">
    <li><span><i class="fa fa-check"></i> 
    Agreeableness
    </span> <span>: 
    """ + " " + str(data[index[0]][2]) + """
    </span></li>
    <li><span><i class="fa fa-check"></i>
     Conscientiousness
    </span> <span>:
    """ + " " + str(data[index[0]][3]) + """
    </span></h3>
    <li><span><i class="fa fa-check"></i> 
     Extraversion
    </span> <span>:
    """ + " " + str(data[index[0]][4]) + """
    </span></li>
    <li><span><i class="fa fa-check"></i> 
     Emotional range
    </span> <span>:
    """ + " " + str(data[index[0]][5]) + """
    </span></li>
    <li><span><i class="fa fa-check"></i> 
     Openness
    </span> <span>:
    """ + " " + str(data[index[0]][6]) + """
    </span></li>
    <li><span><i class="fa fa-check"></i> 
     OVERALL hbd SCORE (in %)
     </span><span>:
    """ + " " + str(100 - hbd[index[0]]*100/3.54) + """
    </span></li>
    </ul>
    </div></div>
    """

html_str_9 = """
    <footer>
    
    <div class="footer-area-bottom">
      <div class="container text-center">
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="credits">
              Designed by Team NS3
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>"""

 

html_str_10 = """    
    <!-- **** All JS Files ***** -->
    <!-- jQuery 2.2.4 -->
    <script src="js/jquery.min.js"></script>
    <!-- Popper -->
    <script src="js/popper.min.js"></script>
    <!-- Bootstrap -->
    <script src="js/bootstrap.min.js"></script>
    <!-- All Plugins -->
    <!--<script src="js/roberto.bundle.js"></script>-->
    <!-- Active -->
    <script src="js/default-assets/active.js"></script>
</header>
"""

#final_str = html_str_1 + html_str_2 + html_str_3 + html_str_4 + html_str_5 + html_str_6 + 
print(html_str_1 + html_str_10 + html_str_2 + html_str_3 + html_str_4 + html_str_5 + html_str_6 + html_str_9)
print('</body>')
print('</html>')


