#!C:\Users\USER\AppData\Local\Programs\Python\Python37\python.exe

import cgi
import csv

print('Content-type:text/html\r\n\r\n')
print('<html>')
print('<body>')

flag = 0
# now the main working body !!!!

form = cgi.FieldStorage()
firstName = form.getfirst('firstname')
secondName = form.getfirst('secondname')
userName = form.getfirst('username')
a1 = float(form.getfirst('a1'))
a2 = float(form.getfirst('a2'))
a3 = float(form.getfirst('a3'))
a4 = float(form.getfirst('a4'))
a5 = float(form.getfirst('a5'))

input_list = [a1, a2, a3, a4, a5]


def HB(v1, v2):
    return (sum((p**.5-q**.5)**2 for p, q in zip(v1, v2)) ** .5)/1.414

similarity = []
data_path = 'Custom_user.csv'
with open(data_path, 'r') as f:
    reader = csv.reader(f, delimiter=',')
    # get header from first row
    headers = next(reader)
    # get all the rows as a list
    data = list(reader)

for i in range(0, len(data)):
    data[i][2:] = [int(x) for x in data[i][2:]]
    x = HB(input_list,data[i][2:])
    similarity.append(x)

index = sorted(range(len(similarity)), key = lambda i: similarity[i], reverse = True)[-5:]
print(index)

# updating Custom_user database only upon registration
#data_t = list(map(list, zip(*data)))

#for i in range(0, len(data_t[0])):
    #if userName == data_t[0][i]:
        #flag = 1
        #break

#if flag == 0:
    #row = [userName, firstName + ' ' + secondName, a1, a2, a3, a4, a5]
    #with open(data_path, 'a', newline='') as csvFile:
        #writer = csv.writer(csvFile)
        #writer.writerow(row)

#print('<html>')
#print('<body>')

#print("<br>")
#print("<h1><center>:::SUGGESTED FRIENDS for " + firstName + " " + secondName + ":::</center></h1>")
#print("<br>")
#print("<hr>")
#print("<b> Username | Name </b>")
#print("<br>")

#for i in index:
    #if data[i][0] != userName:
        #print(data[i][0] + "|" + data[i][1])
        #print("<br>")

#print('</body>')
#print('</html>')


f = open("user_display_1.html", "r")
s = f.read()
print(s)


# No. 1
print('<div class="single-room-slide d-flex align-items-center">')
print('<div class="room-thumbnail h-100 bg-img" style="background-image: url(img/users/user1.jpg);"></div>')
print('<div class="room-content">')
print('<h2 data-animation="fadeInUp" data-delay="100ms">')
print("Name : ")
print(data[index[0]][1])
print("</h2>")
print('<h3 data-animation="fadeInUp" data-delay="300ms">')
print("Username")
print("<span>/ user1:")
print(userName)
print(data[index[0]][0])
print("</span></h3>")
print('<ul class="room-feature" data-animation="fadeInUp" data-delay="500ms">')
print('<li><span><i class="fa fa-check"></i> ')
print(' Agreeableness')
print('</span> <span>:')
print(" " + data[index[0]][2])
print("</span></li>")
print('<li><span><i class="fa fa-check"></i>')
print(' Conscientiousness')
print('</span> <span>: ')
print(data[index[0]][3])
print("</span></h3>")
print('<li><span><i class="fa fa-check"></i> ')
print(' Extraversio')
print("</span> <span>:")
print(" " + data[index[0]][4])
print("</span></li>")
print('<li><span><i class="fa fa-check"></i> ')
print(" Emotional range")
print("</span> <span>:")
print(" " + data[index[0]][5])
print("</span></li>")
print('<li><span><i class="fa fa-check"></i> ')
print(" Openness")
print("</span> <span>:")
print(" " + data[index[0]][6])
print("</span></li>")
print("</ul>")
print("</div></div>")

# No. 2
print('<div class="single-room-slide d-flex align-items-center">')
print('<div class="room-thumbnail h-100 bg-img" style="background-image: url(img/users/user22.jpg);"></div>')
print('<div class="room-content">')
print('<h2 data-animation="fadeInUp" data-delay="100ms">')
print("Name : ")
print(data[index[1]][1])
print("</h2>")
print('<h3 data-animation="fadeInUp" data-delay="300ms">')
print("Username")
print("<span>/ user1:")
print(userName)
print(data[index[1]][0])
print("</span></h3>")
print('<ul class="room-feature" data-animation="fadeInUp" data-delay="500ms">')
print('<li><span><i class="fa fa-check"></i> ')
print(' Agreeableness')
print('</span> <span>:')
print(" " + data[index[1]][2])
print("</span></li>")
print('<li><span><i class="fa fa-check"></i>')
print(' Conscientiousness')
print('</span> <span>: ')
print(data[index[1]][3])
print("</span></h3>")
print('<li><span><i class="fa fa-check"></i> ')
print(' Extraversio')
print("</span> <span>:")
print(" " + data[index[1]][4])
print("</span></li>")
print('<li><span><i class="fa fa-check"></i> ')
print(" Emotional range")
print("</span> <span>:")
print(" " + data[index[1]][5])
print("</span></li>")
print('<li><span><i class="fa fa-check"></i> ')
print(" Openness")
print("</span> <span>:")
print(" " + data[index[1]][6])
print("</span></li>")
print("</ul>")
print("</div></div>")

# No. 3
print('<div class="single-room-slide d-flex align-items-center">')
print('<div class="room-thumbnail h-100 bg-img" style="background-image: url(img/users/user3.jpg);"></div>')
print('<div class="room-content">')
print('<h2 data-animation="fadeInUp" data-delay="100ms">')
print("Name : ")
print(data[index[2]][1])
print("</h2>")
print('<h3 data-animation="fadeInUp" data-delay="300ms">')
print("Username")
print("<span>/ user1:")
print(userName)
print(data[index[2]][0])
print("</span></h3>")
print('<ul class="room-feature" data-animation="fadeInUp" data-delay="500ms">')
print('<li><span><i class="fa fa-check"></i> ')
print(' Agreeableness')
print('</span> <span>:')
print(" " + data[index[2]][2])
print("</span></li>")
print('<li><span><i class="fa fa-check"></i>')
print(' Conscientiousness')
print('</span> <span>: ')
print(data[index[2]][3])
print("</span></h3>")
print('<li><span><i class="fa fa-check"></i> ')
print(' Extraversio')
print("</span> <span>:")
print(" " + data[index[2]][4])
print("</span></li>")
print('<li><span><i class="fa fa-check"></i> ')
print(" Emotional range")
print("</span> <span>:")
print(" " + data[index[2]][5])
print("</span></li>")
print('<li><span><i class="fa fa-check"></i> ')
print(" Openness")
print("</span> <span>:")
print(" " + data[index[2]][6])
print("</span></li>")
print("</ul>")
print("</div></div>")

# No. 4
print('<div class="single-room-slide d-flex align-items-center">')
print('<div class="room-thumbnail h-100 bg-img" style="background-image: url(img/users/user44.jpg);"></div>')
print('<div class="room-content">')
print('<h2 data-animation="fadeInUp" data-delay="100ms">')
print("Name : ")
print(data[index[3]][1])
print("</h2>")
print('<h3 data-animation="fadeInUp" data-delay="300ms">')
print("Username")
print("<span>/ user1:")
print(userName)
print(data[index[3]][0])
print("</span></h3>")
print('<ul class="room-feature" data-animation="fadeInUp" data-delay="500ms">')
print('<li><span><i class="fa fa-check"></i> ')
print(' Agreeableness')
print('</span> <span>:')
print(" " + data[index[3]][2])
print("</span></li>")
print('<li><span><i class="fa fa-check"></i>')
print(' Conscientiousness')
print('</span> <span>: ')
print(data[index[3]][3])
print("</span></h3>")
print('<li><span><i class="fa fa-check"></i> ')
print(' Extraversio')
print("</span> <span>:")
print(" " + data[index[3]][4])
print("</span></li>")
print('<li><span><i class="fa fa-check"></i> ')
print(" Emotional range")
print("</span> <span>:")
print(" " + data[index[3]][5])
print("</span></li>")
print('<li><span><i class="fa fa-check"></i> ')
print(" Openness")
print("</span> <span>:")
print(" " + data[index[3]][6])
print("</span></li>")
print("</ul>")
print("</div></div>")

# No. 5
print('<div class="single-room-slide d-flex align-items-center">')
print('<div class="room-thumbnail h-100 bg-img" style="background-image: url(img/users/user5.jpg);"></div>')
print('<div class="room-content">')
print('<h2 data-animation="fadeInUp" data-delay="100ms">')
print("Name : ")
print(data[index[4]][1])
print("</h2>")
print('<h3 data-animation="fadeInUp" data-delay="300ms">')
print("Username")
print("<span>/ user1:")
print(userName)
print(data[index[4]][0])
print("</span></h3>")
print('<ul class="room-feature" data-animation="fadeInUp" data-delay="500ms">')
print('<li><span><i class="fa fa-check"></i> ')
print(' Agreeableness')
print('</span> <span>:')
print(" " + data[index[4]][2])
print("</span></li>")
print('<li><span><i class="fa fa-check"></i>')
print(' Conscientiousness')
print('</span> <span>: ')
print(data[index[4]][3])
print("</span></h3>")
print('<li><span><i class="fa fa-check"></i> ')
print(' Extraversio')
print("</span> <span>:")
print(" " + data[index[4]][4])
print("</span></li>")
print('<li><span><i class="fa fa-check"></i> ')
print(" Emotional range")
print("</span> <span>:")
print(" " + data[index[4]][5])
print("</span></li>")
print('<li><span><i class="fa fa-check"></i> ')
print(" Openness")
print("</span> <span>:")
print(" " + data[index[4]][6])
print("</span></li>")
print("</ul>")
print("</div></div>")

print("</div></section>")


fn = open("user_display_2.html", "r")
sn = fn.read()
print(sn)

print('</body>')
print('</html>')


