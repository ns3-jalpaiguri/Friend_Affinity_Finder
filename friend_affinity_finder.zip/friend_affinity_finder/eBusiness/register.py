#!C:\Users\USER\AppData\Local\Programs\Python\Python37\python.exe

import cgi
import csv

print('Content-type:text/html\r\n\r\n')

print('<html>')
print('<body>')


flag = 0

form = cgi.FieldStorage()
firstName = form.getfirst('firstName')
secondName = form.getfirst('secondName')
username = form.getfirst('username')
password = form.getfirst('password')

row = [username, password, firstName, secondName]

def write_n_redirect(row):
	with open('database.csv', 'a', newline='') as csvFile:
	    writer = csv.writer(csvFile)
	    writer.writerow(row)

	csvFile.close()

	# INTEGRATION REQUIRED .....

	if (username):
		f = open("formtest.html", "r")
		s = f.read()
		print(s)

with open('database.csv', 'r') as f:
    reader = csv.reader(f, delimiter=',')
    # get header from first row
    headers = next(reader)
    # get all the rows as a list
    data = list(reader)

data = list(map(list, zip(*data)))


if len(data) != 0:
	for i in range(0,len(data[0])):
		if username == data[0][i]:
			flag = 1
			break
	if flag == 1:
		f = open("failreg.html", "r")
		s = f.read()
		print(s)

	if flag == 0:
		write_n_redirect(row)

else:
	write_n_redirect(row)
	 


print('</body>')
print('</html>')