#!C:\Users\USER\AppData\Local\Programs\Python\Python37\python.exe

import cgi
import csv

print('Content-type:text/html\r\n\r\n')

print('<html>')
print('<body>')

flag = 0
form = cgi.FieldStorage()
username = form.getfirst('username')
password = form.getfirst('password')


with open('database.csv', 'r') as f:
    reader = csv.reader(f, delimiter=',')
    # get header from first row
    headers = next(reader)
    # get all the rows as a list
    data = list(reader)

# searching username and password

data = list(map(list, zip(*data)))

if len(data) != 0:
	for i in range(0,len(data[0])):
		if username == data[0][i]:
			if password == data[1][i]:
				# INTEGRATION REQUIRED .....
					#print("login success")
				flag = 1
				f = open("formtest.html", "r")
				s = f.read()
				print(s)
				break
			else:
				redirectURL = "http://localhost/friend_affinity_finder/eBusiness/loginfail.html"
				#print("password wrong")
				flag = 1
				print('<meta http-equiv="refresh" content="0;url='+str(redirectURL)+'" />')
				break

	if flag == 0:
		f = open("loginfail.html", "r")
		s = f.read()
		print(s)


else:
	redirectURL = "http://localhost/friend_affinity_finder/eBusiness/registration.html"
	print('<meta http-equiv="refresh" content="0;url='+str(redirectURL)+'" />')	
	





print('</body>')
print('</html>')