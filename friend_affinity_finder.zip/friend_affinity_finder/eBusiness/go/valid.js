$(function() {

  $.validator.setDefaults({
    errorClass: 'help-block',
    highlight: function(element) {
      $(element)
        .closest('.form-group')
        .addClass('has-error');
    },
    unhighlight: function(element) {
      $(element)
        .closest('.form-group')
        .removeClass('has-error');
    },
    errorPlacement: function (error, element) {
      if (element.prop('type') === 'checkbox') {
        error.insertAfter(element.parent());
      } else {
        error.insertAfter(element);
      }
    }
  });

  $.validator.addMethod('strongPassword', function(value, element) {
    return this.optional(element) 
      || value.length >= 6
      && /\d/.test(value)
      && /[a-z]/i.test(value);
  }, 'Your password must be at least 6 characters long and contain at least one number and one char\'.')


$.validator.addMethod('goodValue', function(value , element)
{
  value= parseFloat(value);
  return this.optional(element) ||   value > 0 && value <= 5.00

} , 'Your value must be between 0-5\'.')


  $("#register-form").validate({
    rules: {
      
       password: {
        required: true,
        strongPassword: true
      },
      password2: {
        required: true,
        equalTo: '#password',
        
      },
      
      firstName: {
        required: true,
        nowhitespace: true,
        lettersonly: true
      },
      secondName: {
        required: true,
        nowhitespace: true,
        lettersonly: true
      },
       userName: {
        required: true,
        nowhitespace: true
        
      },
      a1: {
        goodValue: true,
        required: true,
        Number: true
      },
      a2: {
        goodValue: true,
        required: true,
        number: true
      },
      a3: {
        goodValue: true,
        required: true,
        number: true
      },
      a4: {
        goodValue: true,
        required: true,
        number: true
      },
      a5: {
        goodValue: true,
        required: true,
        number: true
      },
      terms: {
        required: true
      }
    },
    messages: {
      a1: {
        required: 'Mandatory Field.',
        
      
      }
    }
  });

});