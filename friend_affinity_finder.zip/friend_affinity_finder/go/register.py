#!C:\Users\ADMIN\AppData\Local\Programs\Python\Python37\python.exe

import cgi
import csv

print('Content-type:text/html\r\n\r\n')

print('<html>')
print('<body>')


flag = 0

form = cgi.FieldStorage()
firstName = form.getfirst('firstName')
secondName = form.getfirst('secondName')
username = form.getfirst('username')
password = form.getfirst('password')

row = [username, password, firstName, secondName]

def write_n_redirect(row):
	with open('database.csv', 'a', newline='') as csvFile:
	    writer = csv.writer(csvFile)
	    writer.writerow(row)

	csvFile.close()

	# INTEGRATION REQUIRED .....

	if (username):
		str1 = """
				<!DOCTYPE html>
				<html lang="en">
				<head>
				    <meta charset="UTF-8">
				    <meta name="viewport" content="width=device-width, initial-scale=1.0">
				    <meta http-equiv="X-UA-Compatible" content="ie=edge">
				    <title>DetailsEntry</title>

				    <!-- Font Icon -->
				    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">

				    <!-- Main css -->
				    <link rel="stylesheet" href="css/style.css">
						<style>
				body {
				  margin: 0;
				  font-family: Arial, Helvetica, sans-serif;
				}

				.topnav {
				  overflow: hidden;
				  background-color: #333;
				}

				.topnav a {
				  float: left;
				  color: #f2f2f2;
				  text-align: center;
				  padding: 14px 16px;
				  text-decoration: none;
				  font-size: 17px;
				}


				.topnav a.active {
				  background-color: #4CAF50;
				  color: white;
				}
				</style>
					
				</head>
				<body background="img/data.jpg">

				<div class="row">
				<div class="topnav">
				<div class="col-md-6 col-sm-12 col-xs-12">
				<a><font color=lightblue>FA</font>Finder</a>	
				</div>
				<div class="col-md-6 col-sm- col-xs-12">
				  <a href="http://localhost/friend_affinity_finder/index.html"> <span>Home</span></a>
				  </div>
				<center>
					<div align="right"><h3><font color = "white">""" + username + """</font></h3></div>
				</center>
				</div>
				</div>
				"""
		f = open("form.html", "r")
		s = f.read()
				#print('<center><h3><font color = "white">WELCOME ' + username + '</font></h3></center>')
		print(str1 + s)




		#f = open("formtest.html", "r")
		#s = f.read()
		#print('<center><h3><font color = "white">WELCOME ' + username + '</font></h3></center>')
		#print(s)

with open('database.csv', 'r') as f:
    reader = csv.reader(f, delimiter=',')
    # get header from first row
    headers = next(reader)
    # get all the rows as a list
    data = list(reader)

data = list(map(list, zip(*data)))


if len(data) != 0:
	for i in range(0,len(data[0])):
		if username == data[0][i]:
			flag = 1
			break
	if flag == 1:
		f = open("failreg.html", "r")
		s = f.read()
		print(s)

	if flag == 0:
		write_n_redirect(row)

else:
	write_n_redirect(row)
	 


print('</body>')
print('</html>')