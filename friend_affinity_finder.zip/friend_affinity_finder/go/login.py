#!C:\Users\ADMIN\AppData\Local\Programs\Python\Python37\python.exe

import cgi
import csv

print('Content-type:text/html\r\n\r\n')

print('<html>')
print('<body>')

flag = 0
form = cgi.FieldStorage()
username = form.getfirst('username')
password = form.getfirst('password')


with open('database.csv', 'r') as f:
    reader = csv.reader(f, delimiter=',')
    # get header from first row
    headers = next(reader)
    # get all the rows as a list
    data = list(reader)

# searching username and password

data = list(map(list, zip(*data)))

if len(data) != 0:
	for i in range(0,len(data[0])):
		if username == data[0][i]:
			if password == data[1][i]:
				# INTEGRATION REQUIRED .....
					#print("login success")
				flag = 1

				str1 = """
				<!DOCTYPE html>
				<html lang="en">
				<head>
				    <meta charset="UTF-8">
				    <meta name="viewport" content="width=device-width, initial-scale=1.0">
				    <meta http-equiv="X-UA-Compatible" content="ie=edge">
				    <title>DetailsEntry</title>

				    <!-- Font Icon -->
				    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">

				    <!-- Main css -->
				    <link rel="stylesheet" href="css/style.css">
						<style>
				body {
				  margin: 0;
				  font-family: Arial, Helvetica, sans-serif;
				}

				.topnav {
				  overflow: hidden;
				  background-color: #333;
				}

				.topnav a {
				  float: left;
				  color: #f2f2f2;
				  text-align: center;
				  padding: 14px 16px;
				  text-decoration: none;
				  font-size: 17px;
				}


				.topnav a.active {
				  background-color: #4CAF50;
				  color: white;
				}
				</style>
					
				</head>
				<body background="img/data.jpg">

				<div class="row">
				<div class="topnav">
				<div class="col-md-6 col-sm-12 col-xs-12">
				<a><font color=lightblue>FA</font>Finder</a>	
				</div>
				<div class="col-md-6 col-sm- col-xs-12">
				  <a href="http://localhost/friend_affinity_finder/index.html"> <span>Home</span></a>
				  </div>
				<center>
					<div align="right"><h3><font color = "white">""" + username + """</font></h3></div>
				</center>
				</div>
				</div>
				"""
				f = open("form.html", "r")
				s = f.read()
				#print('<center><h3><font color = "white">WELCOME ' + username + '</font></h3></center>')
				print(str1 + s)
				break
			else:
				redirectURL = "http://localhost/friend_affinity_finder/go/loginfail.html"
				#print("password wrong")
				flag = 1
				print('<meta http-equiv="refresh" content="0;url='+str(redirectURL)+'" />')
				break

	if flag == 0:
		f = open("loginfail.html", "r")
		s = f.read()
		print(s)


else:
	redirectURL = "http://localhost/friend_affinity_finder/go/register.html"
	print('<meta http-equiv="refresh" content="0;url='+str(redirectURL)+'" />')	
	





print('</body>')
print('</html>')